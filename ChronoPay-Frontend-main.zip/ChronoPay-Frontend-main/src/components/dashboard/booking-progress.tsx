import { HelpPopover } from "@/app/components/ui/help-popover";
import { glossary } from "@/lib/glossary";
import type { BookingStage } from "./types";

export function BookingProgress({ stages }: { stages: BookingStage[] }) {
  const maxValue = Math.max(...stages.map((stage) => stage.value), 1);

  return (
    <div className="space-y-5">
      {/* Heading row — "Booking stages" label with lifecycle explanation */}
      <div className="flex items-center gap-2 mb-1">
        <p className="text-xs font-medium uppercase tracking-wide text-slate-400">
          Booking stages
        </p>
        <HelpPopover
          term={glossary.bookingStages}
          triggerLabel="Help: booking lifecycle stages"
        />
      </div>

      {stages.map((stage, index) => {
        const labelId = `booking-label-${index}`;
        const valueId = `booking-value-${index}`;
        return (
          <div
            key={`${stage.label}-${index}`}
            role="listitem"
            aria-labelledby={labelId}
            aria-describedby={valueId}
          >
            <div className="mb-2 flex items-center justify-between gap-3">
              <p id={labelId} className="text-sm font-medium text-white">
                {stage.label}
              </p>
              <p id={valueId} className="text-sm text-slate-300" aria-atomic="true">
                {stage.value} bookings
              </p>
            </div>
            <div className="h-2.5 rounded-full bg-white/10" aria-hidden="true">
              <div
                className="h-2.5 rounded-full bg-[linear-gradient(90deg,#67e8f9,#22c55e)]"
                style={{ width: `${(stage.value / maxValue) * 100}%` }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}
